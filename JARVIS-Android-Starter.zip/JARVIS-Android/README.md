# JARVIS Android Starter

A starter Android app for Android 8+ (tested target configuration is API 35 / Android 15; should run on Android 16).

## Included
- Futuristic dark blue Compose interface
- Speech-to-text via Android's system speech recognizer
- Spoken replies using Android TextToSpeech
- Local commands: time, date, help
- Launch YouTube, Instagram, WhatsApp, Settings, Camera
- Web search command
- Simple in-session activity log

## Important limitations
- This is a starter app, not a full Iron Man-style system assistant.
- It does not yet include an online AI API, persistent reminders, notification access, always-on wake word, or broad accessibility automation.
- Speech recognition may require an internet connection depending on the device's installed speech service.
- App-launch intents can fail if an app isn't installed.
- No API keys or personal data are embedded.

## Build APK
1. Install Android Studio on a computer, or use a trusted cloud Android build environment that supports Gradle Android projects.
2. Open this project folder.
3. Let Gradle sync and install any requested Android SDK components.
4. Build > Build APK(s).
5. Install the generated debug APK on your Android phone. You may need to allow installs from the app used to open the APK.
6. Grant microphone permission when prompted.

## Try commands
- Open YouTube
- Open Instagram
- Open WhatsApp
- Open Settings
- Open Camera
- What time is it?
- What's today's date?
- Search space news
- Help

## Next development steps
1. Add secure backend integration for online AI; never ship a private API key in the APK.
2. Add persistent reminders with Android scheduling APIs.
3. Add notification listener only after clear user consent.
4. Add accessibility automation only for clearly disclosed, user-enabled workflows.
5. Implement wake-word detection only after evaluating battery use and Android background restrictions.
