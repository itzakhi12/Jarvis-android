package com.aklesh.jarvis

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.speech.RecognizerIntent
import android.speech.tts.TextToSpeech
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Send
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import java.util.Locale

private val Navy = Color(0xFF050B16)
private val Panel = Color(0xFF0D1A2B)
private val Cyan = Color(0xFF36D7FF)
private val Soft = Color(0xFFB8C9D9)

class MainActivity : ComponentActivity(), TextToSpeech.OnInitListener {
    private var tts: TextToSpeech? = null
    private var ttsReady = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        tts = TextToSpeech(this, this)
        setContent { JarvisScreen(onCommand = { runCommand(it) }, onListen = { startListening() }) }
    }

    override fun onInit(status: Int) {
        ttsReady = status == TextToSpeech.SUCCESS
        if (ttsReady) tts?.language = Locale.getDefault()
    }

    private fun speak(message: String) {
        if (ttsReady) tts?.speak(message, TextToSpeech.QUEUE_FLUSH, null, "jarvis_reply")
    }

    private fun runCommand(raw: String): String {
        val command = raw.trim()
        val c = command.lowercase(Locale.getDefault())
        val reply = when {
            c.isBlank() -> "Please tell me what you need."
            c.contains("hello") || c.contains("hey jarvis") || c == "hi" ->
                "Hello. JARVIS is online. What can I do for you?"
            c.contains("time") -> "The current time is ${java.text.SimpleDateFormat("h:mm a", Locale.getDefault()).format(java.util.Date())}."
            c.contains("date") || c.contains("today") ->
                "Today is ${java.text.SimpleDateFormat("EEEE, d MMMM yyyy", Locale.getDefault()).format(java.util.Date())}."
            c.contains("open youtube") -> openApp("com.google.android.youtube", "YouTube")
            c.contains("open instagram") -> openApp("com.instagram.android", "Instagram")
            c.contains("open whatsapp") -> openApp("com.whatsapp", "WhatsApp")
            c.contains("open settings") -> {
                startActivity(Intent(android.provider.Settings.ACTION_SETTINGS))
                "Opening Settings."
            }
            c.contains("open camera") -> {
                val intent = Intent("android.media.action.IMAGE_CAPTURE")
                safelyStart(intent, "Camera")
            }
            c.startsWith("search ") -> {
                val q = command.removePrefix("search ").trim()
                val i = Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/search?q=" + Uri.encode(q)))
                safelyStart(i, "Search")
            }
            c.contains("help") || c.contains("what can you do") ->
                "I can tell the time and date, open YouTube, Instagram, WhatsApp, Settings or Camera, and search the web. More controls can be added to this starter app."
            else -> "I heard: $command. Online AI is not connected yet. This starter version handles basic commands locally."
        }
        speak(reply)
        return reply
    }

    private fun openApp(packageName: String, label: String): String {
        val launch = packageManager.getLaunchIntentForPackage(packageName)
        return if (launch != null) {
            startActivity(launch)
            "Opening $label."
        } else {
            "I couldn't find $label on this phone."
        }
    }

    private fun safelyStart(intent: Intent, label: String): String {
        return try {
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            startActivity(intent)
            "Opening $label."
        } catch (_: Exception) {
            "$label is not available on this phone."
        }
    }

    private fun startListening() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 42)
            Toast.makeText(this, "Allow microphone access, then tap the mic again.", Toast.LENGTH_LONG).show()
            return
        }
        try {
            val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault())
                putExtra(RecognizerIntent.EXTRA_PROMPT, "Speak to JARVIS")
            }
            speechLauncher.launch(intent)
        } catch (_: Exception) {
            Toast.makeText(this, "Speech recognition isn't available on this device.", Toast.LENGTH_LONG).show()
        }
    }

    private val speechLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        val text = result.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()
        if (!text.isNullOrBlank()) {
            val response = runCommand(text)
            Toast.makeText(this, response, Toast.LENGTH_LONG).show()
        }
    }

    override fun onDestroy() {
        tts?.stop()
        tts?.shutdown()
        super.onDestroy()
    }
}

@Composable
private fun JarvisScreen(onCommand: (String) -> String, onListen: () -> Unit) {
    var input by remember { mutableStateOf("") }
    var response by remember { mutableStateOf("Systems ready. Tap the microphone or enter a command.") }
    var history by remember { mutableStateOf(listOf("JARVIS: Welcome back. How can I assist you?")) }

    fun submit(text: String) {
        if (text.isBlank()) return
        val answer = onCommand(text)
        history = history + "YOU: $text" + "JARVIS: $answer"
        response = answer
        input = ""
    }

    MaterialTheme(colorScheme = darkColorScheme(
        primary = Cyan, background = Navy, surface = Panel,
        onBackground = Color.White, onSurface = Color.White
    )) {
        Column(
            Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color(0xFF071426), Navy, Color(0xFF02050A)))
            ).padding(20.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Spacer(Modifier.height(18.dp))
            Text("J.A.R.V.I.S.", color = Cyan, fontSize = 30.sp, fontWeight = FontWeight.Bold, letterSpacing = 5.sp)
            Text("PERSONAL AI ASSISTANT", color = Soft, fontSize = 11.sp, letterSpacing = 3.sp)
            Spacer(Modifier.height(28.dp))
            Box(
                Modifier.size(176.dp).background(
                    Brush.radialGradient(listOf(Color(0xFF174D70), Color(0xFF0A1B31), Navy)),
                    CircleShape
                ),
                contentAlignment = Alignment.Center
            ) {
                Surface(
                    modifier = Modifier.size(112.dp),
                    shape = CircleShape,
                    color = Color(0xFF102E49),
                    border = androidx.compose.foundation.BorderStroke(2.dp, Cyan)
                ) {
                    Box(contentAlignment = Alignment.Center) {
                        Icon(Icons.Default.Mic, contentDescription = "Voice input", tint = Cyan, modifier = Modifier.size(52.dp))
                    }
                }
            }
            Spacer(Modifier.height(12.dp))
            Text("SYSTEM ONLINE", color = Cyan, fontSize = 12.sp, fontWeight = FontWeight.SemiBold, letterSpacing = 2.sp)
            Spacer(Modifier.height(18.dp))
            Surface(color = Panel, shape = RoundedCornerShape(16.dp), modifier = Modifier.fillMaxWidth()) {
                Text(response, color = Soft, modifier = Modifier.padding(16.dp), fontSize = 14.sp)
            }
            Spacer(Modifier.height(12.dp))
            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
                OutlinedTextField(
                    value = input, onValueChange = { input = it },
                    placeholder = { Text("Type a command…", color = Soft) },
                    modifier = Modifier.weight(1f),
                    shape = RoundedCornerShape(14.dp),
                    singleLine = true
                )
                Spacer(Modifier.width(8.dp))
                IconButton(onClick = { submit(input) }) {
                    Icon(Icons.Default.Send, contentDescription = "Send command", tint = Cyan)
                }
            }
            Spacer(Modifier.height(8.dp))
            Button(
                onClick = onListen,
                modifier = Modifier.fillMaxWidth().height(52.dp),
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF0E5273)),
                shape = RoundedCornerShape(14.dp)
            ) {
                Icon(Icons.Default.Mic, contentDescription = null)
                Spacer(Modifier.width(8.dp))
                Text("TALK TO JARVIS", fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
            }
            Spacer(Modifier.height(16.dp))
            Text("TRY: “OPEN YOUTUBE” • “WHAT TIME IS IT?” • “SEARCH SPACE NEWS”", color = Soft, fontSize = 9.sp)
            Spacer(Modifier.height(12.dp))
            Text("ACTIVITY LOG", color = Cyan, fontSize = 12.sp, letterSpacing = 2.sp, modifier = Modifier.align(Alignment.Start))
            Spacer(Modifier.height(6.dp))
            LazyColumn(Modifier.fillMaxWidth().weight(1f)) {
                items(history.takeLast(8).reversed()) { item ->
                    Text(item, color = Soft, fontSize = 12.sp, modifier = Modifier.padding(vertical = 4.dp))
                }
            }
        }
    }
}
